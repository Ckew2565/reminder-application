package com.example.remember_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
